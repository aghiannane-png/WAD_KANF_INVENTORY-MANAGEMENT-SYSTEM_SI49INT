<?php $__env->startSection('title', 'Dashboard - Inventory Information Systems'); ?>

<?php $__env->startSection('glows'); ?>
  <div class="glow glow--white" aria-hidden="true"></div>
  <div class="glow glow--pink-top" aria-hidden="true"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <section class="hero">
    <h1>Manage your own Inventory Systems</h1>
    <p>Warehousing, Vendors, Items, and Operational</p>
    <a href="#modules" class="hero-btn"><?php echo e(auth()->user()->hasRole('admin', 'staff') ? 'Start to Add Data' : 'Browse Data'); ?></a>
  </section>

  <section class="cards" id="modules">
    <?php $__currentLoopData = \App\Support\Modules::all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <article class="card">
        <div class="card-head">
          <div class="card-icon">
            <img src="<?php echo e(asset('images/' . $m['icon'])); ?>" width="<?php echo e($m['icon_width']); ?>" alt="">
          </div>
          <h2 class="card-title"><?php echo e($m['label']); ?></h2>
        </div>

        <div class="card-actions">
          <?php $__currentLoopData = \App\Support\Modules::visibleLinks($m, auth()->user()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route($link['route'])); ?>" class="card-btn card-btn--<?php echo e($link['type']); ?>"><?php echo e($link['label']); ?></a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </article>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\inventory-information-system\resources\views/dashboard.blade.php ENDPATH**/ ?>