<?php $__env->startSection('title', 'Register - Inventory Information Systems'); ?>

<?php $__env->startSection('glows'); ?>
  <div class="glow glow--pink-small" aria-hidden="true"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <h1 class="page-title">Register Here!</h1>

  <div class="panel panel--center">
    <form method="POST" action="<?php echo e(route('register.store')); ?>">
      <?php echo csrf_field(); ?>

      <div class="field">
        <label for="name">Insert Username</label>
        <input type="text" id="name" name="name" value="<?php echo e(old('name')); ?>" required maxlength="50" autocomplete="username">
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="field-error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      <div class="field">
        <label for="email">Insert Email</label>
        <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>" required autocomplete="email">
        <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="field-error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      <div class="field">
        <label for="password">Insert Password</label>
        <input type="password" id="password" name="password" required minlength="8" autocomplete="new-password">
        <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="field-error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      <div class="field">
        <label for="password_confirmation">Confirm Password</label>
        <input type="password" id="password_confirmation" name="password_confirmation" required autocomplete="new-password">
      </div>

      <div class="panel-actions">
        <button type="submit" class="btn btn--outline">Register</button>
      </div>
      <p class="panel-link">Already have an account? <a href="<?php echo e(route('login')); ?>#login">Login</a></p>
    </form>
  </div>

  <div style="height: 70px;"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\inventory-information-system\resources\views/register.blade.php ENDPATH**/ ?>