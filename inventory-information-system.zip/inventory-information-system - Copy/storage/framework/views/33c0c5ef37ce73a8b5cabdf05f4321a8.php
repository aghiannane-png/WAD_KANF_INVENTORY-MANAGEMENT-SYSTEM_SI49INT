<?php
  $modules = \App\Support\Modules::all();
  $current = collect($modules)->first(fn ($m) => request()->routeIs($m['pattern']));
  $openKey = $current['key'] ?? $modules[0]['key'];
?>

<div class="sidebar-overlay" id="sidebar-overlay"></div>

<aside class="sidebar" id="sidebar" aria-label="Main navigation" aria-hidden="true">
  <nav>
    <?php $__currentLoopData = $modules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php $open = $openKey === $m['key']; ?>
      <div class="nav-group <?php echo e($open ? 'is-open' : ''); ?>">
        <button type="button" class="nav-parent" aria-expanded="<?php echo e($open ? 'true' : 'false'); ?>">
          <span><?php echo e($m['label']); ?></span>
          <i class="nav-arrow" aria-hidden="true"></i>
        </button>
        <div class="nav-children">
          <?php $__currentLoopData = \App\Support\Modules::visibleLinks($m, auth()->user()); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $link): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e(route($link['route'])); ?>" class="nav-child <?php echo e(request()->routeIs($link['route']) ? 'is-current' : ''); ?>"><?php echo e($link['label']); ?></a>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </nav>
</aside>
<?php /**PATH C:\laragon\www\inventory-information-system\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>