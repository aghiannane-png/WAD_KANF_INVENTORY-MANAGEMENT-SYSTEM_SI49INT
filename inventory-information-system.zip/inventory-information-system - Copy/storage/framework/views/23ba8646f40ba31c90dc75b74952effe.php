<?php $__env->startSection('title', 'Inventory Information Systems'); ?>

<?php $__env->startSection('glows'); ?>
  <div class="glow glow--white" aria-hidden="true"></div>
  <div class="glow glow--pink-top" aria-hidden="true"></div>
  <div class="glow glow--pink-bottom" aria-hidden="true"></div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <section class="hero">
    <h1>Manage your own Inventory Systems</h1>
    <p>Warehousing, Vendors, Items, and Operational</p>
    <a href="#login" class="hero-btn">Register or Login</a>
  </section>

  <section class="login-section" id="login">
    <div class="tagline">
      <span class="tagline-bar" aria-hidden="true"></span>
      <h2>Your Inventory Systems in One Click Away</h2>
    </div>

    <div class="panel panel--login">
      <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

      <form method="POST" action="<?php echo e(route('login.attempt')); ?>">
        <?php echo csrf_field(); ?>

        <div class="field">
          <label for="email">Login with Email</label>
          <input type="email" id="email" name="email" value="<?php echo e(old('email')); ?>" placeholder="e.g, googlemail@gmail.com" required autocomplete="email">
          <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="field-error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="field">
          <label for="password">Insert Password</label>
          <input type="password" id="password" name="password" placeholder="e.g, googlemail123" required autocomplete="current-password">
          <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="field-error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>

        <div class="btn-stack btn-stack--login">
          <button type="submit" class="btn btn--lime">Login</button>
          <a href="<?php echo e(route('register')); ?>" class="btn btn--outline">Register</a>
        </div>
      </form>
    </div>
  </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.guest', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\inventory-information-system\resources\views/main.blade.php ENDPATH**/ ?>