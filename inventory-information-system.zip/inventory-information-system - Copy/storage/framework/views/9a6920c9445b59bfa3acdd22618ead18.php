<?php $__env->startSection('title', 'Warehouse Zoning & Rack Data - Inventory Information Systems'); ?>

<?php $__env->startSection('content'); ?>
<main class="list-wrap">
  <?php echo $__env->make('partials.flash', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <div class="list-card">
    <h2>Warehouse Zoning &amp; Rack Data</h2>

    <div class="table-wrap">
      <div class="table-scroll">
        <table>
          <thead>
            <tr>
              <th>Warehouse Name</th>
              <th>Aisle Number</th>
              <th>Rack Code</th>
              <th>Physical Capacity</th>
              <th>Action</th>
            </tr>
          </thead>
          <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
              <tr>
                <td><?php echo e($warehouse->warehouse_name); ?></td>
                <td><?php echo e($warehouse->aisle_number); ?></td>
                <td><?php echo e($warehouse->rack_code); ?></td>
                <td><?php echo e($warehouse->physical_capacity); ?></td>
                <td>
                  <div class="action-buttons">
                    <a href="<?php echo e(route('warehouses.edit', $warehouse)); ?>" class="btn-edit">Edit</a>
                    <form method="POST" action="<?php echo e(route('warehouses.destroy', $warehouse)); ?>" data-confirm="Are you sure you want to delete this warehouse?">
                      <?php echo csrf_field(); ?>
                      <?php echo method_field('DELETE'); ?>
                      <button type="submit" class="btn-delete">Delete</button>
                    </form>
                  </div>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
              <tr class="empty-row"><td colspan="5">No warehouses added yet.</td></tr>
            <?php endif; ?>
          </tbody>
        </table>
      </div>
    </div>

    <a href="<?php echo e(route('warehouses.create')); ?>" class="btn-add">Add Another Warehouse</a>
  </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\inventory-information-system\resources\views/warehouses/index.blade.php ENDPATH**/ ?>