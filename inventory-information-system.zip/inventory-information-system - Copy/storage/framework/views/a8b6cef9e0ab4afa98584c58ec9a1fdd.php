<?php $__env->startSection('title', 'Add Warehouse - Inventory Information Systems'); ?>

<?php $__env->startSection('content'); ?>
<main class="content">
  <div class="intro">
    <span class="accent-bar" aria-hidden="true"></span>
    <h1>Warehouse Zoning and Rack</h1>
  </div>

  <div class="panel">
    <form method="POST" action="<?php echo e(route('warehouses.store')); ?>">
      <?php echo csrf_field(); ?>
      <?php echo $__env->make('warehouses._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
      <div class="form-actions">
        <button type="submit" class="btn btn--lime">SAVE</button>
      </div>
    </form>
  </div>
</main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\inventory-information-system\resources\views/warehouses/create.blade.php ENDPATH**/ ?>