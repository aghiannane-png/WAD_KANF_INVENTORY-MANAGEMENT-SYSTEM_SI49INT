<div class="field">
  <label for="warehouse_name">Warehouse Name</label>
  <input type="text" id="warehouse_name" name="warehouse_name" value="<?php echo e(old('warehouse_name', $warehouse->warehouse_name ?? '')); ?>" required>
  <?php $__errorArgs = ['warehouse_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="field-error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="field">
  <label for="aisle_number">Aisle Number</label>
  <input type="text" id="aisle_number" name="aisle_number" value="<?php echo e(old('aisle_number', $warehouse->aisle_number ?? '')); ?>" required>
  <?php $__errorArgs = ['aisle_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="field-error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="field">
  <label for="rack_code">Rack Code</label>
  <input type="text" id="rack_code" name="rack_code" value="<?php echo e(old('rack_code', $warehouse->rack_code ?? '')); ?>" required>
  <?php $__errorArgs = ['rack_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="field-error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>

<div class="field">
  <label for="physical_capacity">Physical Capacity</label>
  <input type="text" id="physical_capacity" name="physical_capacity" value="<?php echo e(old('physical_capacity', $warehouse->physical_capacity ?? '')); ?>" required>
  <?php $__errorArgs = ['physical_capacity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <p class="field-error"><?php echo e($message); ?></p> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div>
<?php /**PATH C:\laragon\www\inventory-information-system\resources\views/warehouses/_form.blade.php ENDPATH**/ ?>