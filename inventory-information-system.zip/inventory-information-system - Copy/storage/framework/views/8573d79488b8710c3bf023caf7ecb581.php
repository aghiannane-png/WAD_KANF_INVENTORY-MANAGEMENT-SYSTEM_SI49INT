<?php if(session('status')): ?>
  <div class="alert alert--ok" role="status"><?php echo e(session('status')); ?></div>
<?php endif; ?>
<?php if(session('error')): ?>
  <div class="alert alert--error" role="alert"><?php echo e(session('error')); ?></div>
<?php endif; ?>
<?php /**PATH C:\laragon\www\inventory-information-system\resources\views/partials/flash.blade.php ENDPATH**/ ?>