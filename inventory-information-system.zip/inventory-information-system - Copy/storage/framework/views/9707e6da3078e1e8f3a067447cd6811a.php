<!DOCTYPE html>
<html lang="en">
<head>
<?php echo $__env->make('partials.head', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</head>
<body>
<div class="page">
  <?php echo $__env->yieldContent('glows'); ?>

  <?php echo $__env->make('partials.header-app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <div class="page-main" id="page-main">
    <?php echo $__env->yieldContent('content'); ?>
  </div>
</div>

<?php echo $__env->make('partials.sidebar', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<script src="<?php echo e(asset('js/app.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\laragon\www\inventory-information-system\resources\views/layouts/app.blade.php ENDPATH**/ ?>